# 🚀 Cómo subir el dashboard al repo de GitHub

Tu repo: **https://github.com/javierbartaburu-dotcom/datafixy**

Tenés 3 opciones según qué sea más cómodo para vos:

---

## ✅ OPCIÓN 1 (más simple) — Subir el HTML directo desde la web de GitHub

Esta es la más fácil si no querés usar terminal.

1. **Descargar el archivo `Fixy_Dashboard_Offline.html`** que ya te entregué
2. Abrir https://github.com/javierbartaburu-dotcom/datafixy
3. En el repo vacío, click en **"uploading an existing file"** (link azul que aparece arriba del listado)
4. **Arrastrar** el archivo `Fixy_Dashboard_Offline.html` al recuadro
5. **IMPORTANTE:** Antes de hacer commit, **renombrar el archivo a `index.html`**
   - Después de subirlo, click en el archivo → botón lápiz (✏️) → cambiar el nombre a `index.html`
6. Escribir mensaje de commit: `Add Fixy Dashboard`
7. Click "Commit changes"

### Activar GitHub Pages (para tener el dashboard online)

1. En el repo → tab **Settings**
2. En el menú izquierdo → **Pages**
3. En **"Source"** → seleccionar **"Deploy from a branch"**
4. Branch: **main** / Folder: **/ (root)** → click **Save**
5. Esperar ~1 minuto
6. El dashboard quedará disponible en:
   **https://javierbartaburu-dotcom.github.io/datafixy/**

---

## 💻 OPCIÓN 2 — Usar el ZIP que ya armé (recomendado, queda más prolijo)

El archivo `datafixy_repo.tar.gz` ya tiene todo configurado (README + .gitignore + commit inicial). Solo necesitás hacer push.

### Paso a paso (desde tu terminal en Windows/Mac/Linux):

```bash
# 1) Descargar y extraer el ZIP
# (en Windows usar 7-Zip o WinRAR, en Mac/Linux: tar xzf datafixy_repo.tar.gz)
tar xzf datafixy_repo.tar.gz

# 2) Entrar al directorio
cd datafixy

# 3) Conectar al repo remoto
git remote add origin https://github.com/javierbartaburu-dotcom/datafixy.git

# 4) Subir todo
git branch -M main
git push -u origin main
```

Te va a pedir tus credenciales de GitHub. Si tenés 2FA activado, necesitás un **Personal Access Token** (no la contraseña):

1. https://github.com/settings/tokens → "Generate new token (classic)"
2. Permisos: marcar **repo** (full control)
3. Copiar el token (se ve UNA sola vez)
4. Cuando git te pida la contraseña, pegás el token

### Activar GitHub Pages (igual que Opción 1)

---

## 🛠️ OPCIÓN 3 — Si ya tenés git instalado y querés hacerlo desde cero

```bash
# 1) Clonar el repo vacío
git clone https://github.com/javierbartaburu-dotcom/datafixy.git
cd datafixy

# 2) Copiar el HTML como index.html
cp /ruta/a/Fixy_Dashboard_Offline.html index.html

# 3) Commit y push
git add index.html
git commit -m "Add Fixy Dashboard"
git push origin main
```

---

## 🔄 Para futuras actualizaciones del dashboard

Cuando actualice el HTML y quieras subir la nueva versión:

```bash
cd datafixy
# Reemplazar el index.html con el nuevo
cp /ruta/al/nuevo/Fixy_Dashboard_Offline.html index.html

# Subir
git add index.html
git commit -m "Update dashboard: <breve descripción del cambio>"
git push
```

GitHub Pages se actualiza automáticamente en ~1 minuto.

---

## 🔐 Consideración importante de privacidad

El dashboard NO incluye los archivos Excel con datos reales. **Nunca subir archivos `.xlsx` al repo público** — el `.gitignore` ya los bloquea automáticamente. Cada usuario que abra el dashboard tiene que cargar sus propios archivos localmente.

Si el repo necesitara ser privado (para no exponer la estructura del dashboard a la competencia):
1. Repo en GitHub → Settings
2. Scroll abajo → "Change visibility" → Private
3. Nota: GitHub Pages privado requiere plan Pro ($4/mes)

---

## 📞 Si algo falla

- **Error de autenticación:** usar Personal Access Token, no contraseña
- **"Updates were rejected":** ejecutar `git pull origin main --rebase` antes del push
- **GitHub Pages no aparece:** esperar 2-3 minutos después de Save y refrescar la URL
